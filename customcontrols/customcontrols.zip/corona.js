mviewer.customControls.corona = (function() {
    /*
     * Private
     */
    var _idlayer = 'corona';

    // stock data
    var _data = [];
    var _orderedDate = [];
    var _dateObj = {};

    var _formatDate = function (date) {
        var d = date.getDate();
        var m = date.getMonth() + 1;
        var year = date.getFullYear();
        var day = d < 10 ? ("0" + d) : d;
        var month = m < 10 ? ("0" + m) : m;
        var formatedDate = [year,month,day].join("/");
        return formatedDate;
    };

    var _formatUTCDate = function (fdate, delimiter) {        
        var Y = fdate.getUTCFullYear();
        var D = fdate.getUTCDate()+1 > 9 ? fdate.getUTCDate()+1 : `0${fdate.getUTCDate()+1}`
        var M = fdate.getUTCMonth()+1 > 9 ? fdate.getUTCMonth()+1 : `0${fdate.getUTCMonth()+1}`
        return [Y,M,D].join(delimiter);
    };    

    // update layer from date
    var _updateLayer = function () {
        var date = $('.coronaInput').val() || '2020/01/25';      
        date = new Date(date);
        date = _formatUTCDate(date,'');
        // get layer source
        var _source = mviewer.getLayers()["corona"].layer.getSource();
        // get data for a date
        var isInRange = false;
        _orderedDate.forEach(e => {
            // to know from wich date we could display data
            if(date === e) {
                isInRange = true;
            }
            // update source and display data
            if(isInRange) {
                setTimeout(() => {
                    _source.clear();
                    _dateObj[date].features.forEach(e => {
                        _source.addFeature(e);
                    })                    
                    _source.refresh()
                }, 2000);                
            }
        })
    }

    _applyFilterToAllLayers = function (time_filter, cc) {
        var coronaInput_layers = ["corona"];
        coronaInput_layers.forEach(function(layer) {
            _setLayerExtraParameters(layer,time_filter, cc);
        });
    }
    _getEveryDays = function (from, to) {
        from = _formatUTCDate(from);
        to = _formatUTCDate(to);
        var date = new Date(from)
        var dates = [];
        while(_formatDate(date) != to ) {
            // request
            dates.push(_formatDate(date));
            // up date
            date.setUTCDate(date.getUTCDate() + 1);
        }
        return dates;
    }

    _getFeaturesFromDate = function(date, features,) {
        date = new Date(date);
        var selection = [];
        // filter features
        features.forEach(e => {
            var fdate = new Date(e.properties.date);
            var D = fdate.getUTCDate()+1 > 9 ? fdate.getUTCDate()+1 : `0${fdate.getUTCDate()+1}`
            var M = fdate.getUTCMonth()+1 > 9 ? fdate.getUTCMonth()+1 : `0${fdate.getUTCMonth()+1}`
            fdate = new Date([fdate.getUTCFullYear(),M,D].join('/'));
            if(fdate>date) {
                selection.push(e);
            }
        });
        return selection;
    }

    // get day by date where date is like 2020/01/25
    _getFeaturesByDay = function (date, features) {
        var selection = [];
        // filter features
        features.forEach(e => {
            var fdate = new Date(e.properties.date);
            var D = fdate.getUTCDate()+1 > 9 ? fdate.getUTCDate()+1 : `0${fdate.getUTCDate()+1}`
            var M = fdate.getUTCMonth()+1 > 9 ? fdate.getUTCMonth()+1 : `0${fdate.getUTCMonth()+1}`
            fdate = [fdate.getUTCFullYear(),M,D].join('/');
            // control string not Date object
            if(fdate===date) {
                selection.push(e);
            }
        });
        return selection;        
    }

    _getWFSParams = function() {
        // getFeatures
        return {
            "test":"test",
            "service": "WFS",
            "version": "1.0.0",
            "request": "GetFeature",
            "typenames": "corona:datacorona",
            "srsname": "EPSG:3857",
            "outputformat": "application/json"
        }     
    }


    return {
        /*
         * Public
         */

        init: function () {
            // mandatory - code executed when panel is opened
            $(".coronaInput.datepicker").datepicker({
                todayHighlight: true
            });

            $.ajax({
                type: "GET",
                url: "https://gis.jdev.fr/geoserver/corona/ows",
                data: _getWFSParams(),
                crossDomain: true,
                dataType: "json",
                success: function (result) {
                    _data = result.features;                   
                    _data.forEach(e=>{
                        var fdate = new Date(e.properties.date);
                        fdate = _formatUTCDate(fdate, '');
                        if(_orderedDate.indexOf(fdate) < 0) {
                            _orderedDate.push(fdate);
                            _dateObj[fdate] = {
                                features: []
                            }
                        }
                        var feature = new ol.Feature({
                            id: e.id,
                            properties: e.properties,
                            geometry: new ol.geom.Point(e.geometry.coordinates)
                        });
                        _dateObj[fdate].features.push(feature);
                    
                    });
                    _orderedDate.sort();
                    console.log(_orderedDate);
                    console.log(_dateObj);
                    
                    //_source.addFeature(feature);
                    //_source.refresh();
                    //var days = _getEveryDays(date, new Date());
                    /*days.forEach(d => {
                        // get every features for a day
                        var selection = _getFeaturesByDay(d, features);
                        // clear old features
                        _source.clear();
                        // add feature to source
                        selection.forEach(e => {
                            var geom = new ol.geom.Point(e.geometry.coordinates);
                            var feature = new ol.Feature({
                                id: e.id,
                                properties: e.properties
                            })
                            _source.addFeature(feature);
                            _source.refresh();
                        })
                    })*/
                }   
            });         
            // getFeatures
            $(".corona-date-values").change(function(e) {
                _updateLayer();
            });
        },

        filter: function (cc) {
            var dates = [];
            var result = _data.filter(item => item.properties.cloudCoverPercentage <= cc);
            result.forEach(function(item, id) {
                if (dates.indexOf(item.properties.date) === -1) {
                    dates.push(item.properties.date);
                }
            });

            return dates;
        },

        destroy: function () {
            // mandatory - code executed when panel is closed

        }
     };

}());
